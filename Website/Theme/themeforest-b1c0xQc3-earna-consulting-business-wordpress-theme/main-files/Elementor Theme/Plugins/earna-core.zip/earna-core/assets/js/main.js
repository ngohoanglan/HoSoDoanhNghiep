;(function($){
    
    $(window).on('elementor/frontend/init',function(){
        elementorFrontend.hooks.addAction('frontend/element_ready/client.default',function(scope,$){
            $(scope).find('.owl-carousel').each(function() {
                $('.partner-carousel').owlCarousel({
        loop: false,
        margin: 20,
        nav: false,
        navText: [
            "<i class='fa fa-angle-left'></i>",
            "<i class='fa fa-angle-right'></i>"
        ],
        dots: false,
        autoplay: true,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 2
            },
            1000: {
                items: 3
            }
        }
    });

            });
        });
    });
    
    $(window).on('elementor/frontend/init',function(){
        elementorFrontend.hooks.addAction('frontend/element_ready/testimonial.default',function(scope,$){
            $(scope).find('.owl-carousel').each(function() {
            
            $('.testimonials-carousel').owlCarousel({
        loop: false,
        nav: true,
        margin:30,
        dots: false,
        autoplay: false,
        items: 1,
        navText: [
            "<i class='arrow_left'></i>",
            "<i class='arrow_right'></i>"
        ]
    });

            });
        });
    });
    
    $(window).on('elementor/frontend/init',function(){
        elementorFrontend.hooks.addAction('frontend/element_ready/testimonial2.default',function(scope,$){
            $(scope).find('.owl-carousel').each(function() {
            
            $('.testimonials-carousel').owlCarousel({
        loop: false,
        nav: true,
        margin:30,
        dots: false,
        autoplay: false,
        items: 1,
        navText: [
            "<i class='arrow_left'></i>",
            "<i class='arrow_right'></i>"
        ]
    });

            });
        });
    });
    
    $(window).on('elementor/frontend/init',function(){
        elementorFrontend.hooks.addAction('frontend/element_ready/case.default',function(scope,$){
            $(scope).find('.owl-carousel').each(function() {
            
            $('.projects-carousel').owlCarousel({
        loop: true,
        center: true,
        margin: 70,
        nav: true,
        navText: [
            "<i class='fa fa-angle-left'></i>",
            "<i class='fa fa-angle-right'></i>"
        ],
        dots: false,
        autoplay: true,
        responsive: {
            0: {
                items: 1
            },
            1200: {
                items: 1,
                stagePadding: 200
            },
            1601: {
                items: 1,
                stagePadding: 300
            },
            1900: {
                items: 1,
                stagePadding: 450
            }
        }
    });

            });
        });
    });
    
    $(window).on('elementor/frontend/init',function(){
        elementorFrontend.hooks.addAction('frontend/element_ready/growth.default',function(scope,$){
            
            /*====  Line chart for business growth =====*/
var ctx = document.getElementById("lineChart");
var myChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: ["2002", "2003", "2007", "2012", "2016", "2021"],
        datasets: [{
            label: 'Business Growth',
            data: [3, 5, 12, 8, 11, 28],
            backgroundColor: [
                'rgba(255, 99, 132, 0.5)',
                'rgba(54, 162, 235, 0.5)',
                'rgba(255, 206, 86, 0.5)',
                'rgba(75, 192, 192, 0.5)',
                'rgba(153, 102, 255, 0.5)',
                'rgba(18, 115, 235, 0.5)'
            ],
            borderColor: [
                'rgba(255,99,132,1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(18, 115, 235, 1)'
            ],
            borderWidth: 2
        }]
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero:true
                }
            }]
        }
    }
});
/*====  End line chart =====*/
            
        });
    });
    
    $(window).on('elementor/frontend/init',function(){
        elementorFrontend.hooks.addAction('frontend/element_ready/service5.default',function(scope,$){
            $(scope).find('.owl-carousel').each(function() {
                $('.thumb-services-carousel').owlCarousel({
            loop: false,
            margin: 30,
            nav: false,
            navText: [
                "<i class='fa fa-angle-left'></i>",
                "<i class='fa fa-angle-right'></i>"
            ],
            dots: true,
            autoplay: true,
            responsive: {
                0: {
                    items: 1
                },
                600: {
                    items: 2
                },
                1000: {
                    items: 3
                }
            }
        });

            });
        });
    });
    
    
    

})(jQuery);
