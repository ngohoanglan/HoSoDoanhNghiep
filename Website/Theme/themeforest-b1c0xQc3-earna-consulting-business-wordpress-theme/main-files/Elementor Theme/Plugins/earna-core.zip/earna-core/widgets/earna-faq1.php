<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Elementor earna Hero Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class Elementor_earna_faq1_Widget extends \Elementor\Widget_Base {

    /**
     * Get widget name.
     *
     * Retrieve oEmbed widget name.
     *
     * @since 1.0.0
     * @access public
     * @return string Widget name.
     */
    public function get_name() {
        return 'faq1';
    }

    /**
     * Get widget title.
     *
     * Retrieve oEmbed widget title.
     *
     * @since 1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Faq Home2 Section', 'earna-core' );
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the oEmbed widget belongs to.
     *
     * @since 1.0.0
     * @access public
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'earna' ];
    }

    /**
     * Register oEmbed widget controls.
     *
     * Add input fields to allow the user to customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls() {

        $this->start_controls_section(
            'section1',
            [
                'label' => esc_html__( 'Faq1 Left Section', 'earna-core' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'class', [
                'label'         => esc_html__( 'Class', 'earna-core' ),
                'default' => esc_html__( 'faq-area text-light overflow-hidden', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $this->add_control(
            'img1',
            [
                'label'     => esc_html__( 'Image', 'tanda-core' ),
                'type'      => \Elementor\Controls_Manager::MEDIA,
                'default'   => [
                    'url'       => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );
        
        $this->add_control(
            'icon', [
                'label'         => esc_html__( 'Icon Class', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $this->add_control(
            'title', [
                'label'         => esc_html__( 'Title', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section2',
            [
                'label' => esc_html__( 'About Right Section', 'earna-core' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater1 = new \Elementor\Repeater();

        $repeater1->add_control(
            'heading_id',
            [
                'label'         => esc_html__( 'Heading ID','earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $repeater1->add_control(
            'cl_id',
            [
                'label'         => esc_html__( 'ID','earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $repeater1->add_control(
            'faq1_title',
            [
                'label'         => esc_html__( 'Title','earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $repeater1->add_control(
            'faq1_des',
            [
                'label'         => esc_html__( 'Description','earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXTAREA,
                'label_block'   => true,
            ]
        );

        $this->add_control(
            'list_two',
            [
                'label'     => esc_html__( 'faq1 Box', 'earna-core' ),
                'type'      => \Elementor\Controls_Manager::REPEATER,
                'fields'    => $repeater1->get_controls(),
                'default'   => [
                    [
                        'list_title' => esc_html__( 'Add faq1 Box', 'earna-core' ),
                    ],
                ],
                'title_field' => '{{{ faq1_title }}}',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'design_option1',
            [
                'label'         => esc_html__( 'Content Style Left','earna-core' ),
                'tab'           => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label'         => esc_html__( 'Title Color', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::COLOR,
                'selectors'     => [
                    '{{WRAPPER}} .faq1-area .info > h5'=> 'color: {{VALUE}}',
                    '{{WRAPPER}} .faq1-area .info > h5::after'=> 'background: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name'          => 'title_ty',
                'label'         => esc_html__( 'Title Typography', 'earna-core' ),
                'selector'      => 
                    '{{WRAPPER}} .faq1-area .info > h5',
            ]
        );

        $this->add_control(
            'h_color',
            [
                'label'         => esc_html__( 'Heading Color', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::COLOR,
                'selectors'     => [
                    '{{WRAPPER}} .faq1-area .info h2'=> 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name'          => 'h_ty',
                'label'         => esc_html__( 'Heading Typography', 'earna-core' ),
                'selector'      => 
                    '{{WRAPPER}} .faq1-area .info h2',
            ]
        );

        $this->add_control(
            'bt_color',
            [
                'label'         => esc_html__( 'Button Color', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::COLOR,
                'selectors'     => [
                    '{{WRAPPER}} .faq1-area .info a.btn'=> 'background-color: {{VALUE}};border-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'btt_color',
            [
                'label'         => esc_html__( 'Button Text Color', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::COLOR,
                'selectors'     => [
                    '{{WRAPPER}} .faq1-area .info a.btn'=> 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name'          => 'btt_ty',
                'label'         => esc_html__( 'Button Text Typography', 'earna-core' ),
                'selector'      => 
                    '{{WRAPPER}} .faq1-area .info a.btn',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'design_option2',
            [
                'label'         => esc_html__( 'Content Style Right','earna-core' ),
                'tab'           => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'title_faq1',
            [
                'label'         => esc_html__( 'Title Color', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::COLOR,
                'selectors'     => [
                    '{{WRAPPER}} .faq1-area .faq1-content .card .card-header h4'=> 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name'          => 'title_faq1_ty',
                'label'         => esc_html__( 'Title Typography', 'earna-core' ),
                'selector'      => 
                    '{{WRAPPER}} .faq1-area .faq1-content .card .card-header h4',
            ]
        );

        $this->add_control(
            'des_faq1',
            [
                'label'         => esc_html__( 'Description Color', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::COLOR,
                'selectors'     => [
                    '{{WRAPPER}} p'=> 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name'          => 'des_faq1_ty',
                'label'         => esc_html__( 'Description Typography', 'earna-core' ),
                'selector'      => 
                    '{{WRAPPER}} p',
            ]
        );


        $this->end_controls_section();

    }

    /**
     * Render oEmbed widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render() {

        $faq1_output = $this->get_settings_for_display(); 
        $faq1_box = $faq1_output['list_two'];
       ?>

        <!-- Star Faq
============================================= -->
<div class="<?php echo esc_html($faq1_output['class']); ?>">
    <div class="container">
        <div class="faq-items">
            <div class="icon"><i class="<?php echo esc_attr($faq1_output['icon']); ?>"></i></div>
            <!-- Fixed Thumb -->
            <div class="fixed-thumb">
                <img src="<?php echo esc_url(wp_get_attachment_image_url( $faq1_output['img1']['id'], 'full' ));?>" alt="Thumb">
            </div>
            <!-- End Fixed Thumb -->
            <div class="row align-center">

                <div class="col-lg-10 offset-lg-2">
                    <div class="faq-content">
                        <h2 class="area-title"><?php echo esc_html($faq1_output['title']); ?></h2>
                        <div class="accordion" id="accordionExample">
                            <?php 
                  $counter = 0;
                  if(!empty($faq1_box)):
                  foreach ($faq1_box as $faq1_box1) :
                ?>
                            <div class="card">
                                <div class="card-header" id="<?php echo esc_attr($faq1_box1['heading_id']);?>">
                                    <h4 class="mb-0" data-toggle="collapse" data-target="#<?php echo esc_attr($faq1_box1['cl_id']);?>" aria-expanded="true" aria-controls="<?php echo esc_attr($faq1_box1['cl_id']);?>">
                                         <?php echo esc_html($faq1_box1['faq1_title']);?>
                                    </h4>
                                </div>

                                <div id="<?php echo esc_attr($faq1_box1['cl_id']);?>" class="collapse <?php if($counter == 0){echo esc_attr("show");}?>" aria-labelledby="<?php echo esc_attr($faq1_box1['heading_id']);?>" data-parent="#accordionExample">
                                    <div class="card-body">
                                        <p>
                                            <?php echo esc_html($faq1_box1['faq1_des']);?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <?php 
            $counter++;
            endforeach; endif;
                ?>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</div>
<!-- End Faq -->

    <?php 
}

}