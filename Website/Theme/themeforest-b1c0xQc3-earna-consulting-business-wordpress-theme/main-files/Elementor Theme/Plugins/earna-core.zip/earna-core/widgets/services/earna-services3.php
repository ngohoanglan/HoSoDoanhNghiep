<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Elementor Earna services3 Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class Elementor_earna_services3_Widget extends \Elementor\Widget_Base {

    /**
     * Get widget name.
     *
     * Retrieve oEmbed widget name.
     *
     * @since 1.0.0
     * @access public
     * @return string Widget name.
     */
    public function get_name() {
        return 'services3';
    }

    /**
     * Get widget title.
     *
     * Retrieve oEmbed widget title.
     *
     * @since 1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Services Three Section', 'earna-core' );
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the oEmbed widget belongs to.
     *
     * @since 1.0.0
     * @access public
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'earna' ];
    }

    /**
     * Register oEmbed widget controls.
     *
     * Add input fields to allow the user to customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls() {

        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__( 'Services Three Section', 'earna-core' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'img',
            [
                'label'     => esc_html__( 'BG Image', 'tanda-core' ),
                'type'      => \Elementor\Controls_Manager::MEDIA,
                'default'   => [
                    'url'       => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );
        
        $this->add_control(
            'class',
            [
                'label'         => esc_html__( 'Class','earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );
        
         $this->add_control(
            'title',
            [
                'label'         => esc_html__( 'Title','earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $this->add_control(
            'sub',
            [
                'label'         => esc_html__( 'Sub Title','earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );
        
       $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'icon',
            [
                'label'         => esc_html__( 'Icon Class','earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $repeater->add_control(
            'img1',
            [
                'label'     => esc_html__( 'Image', 'tanda-core' ),
                'type'      => \Elementor\Controls_Manager::MEDIA,
                'default'   => [
                    'url'       => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $repeater->add_control(
            'icon_title',
            [
                'label'         => esc_html__( 'Title','earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $repeater->add_control(
            'icon_des',
            [
                'label'         => esc_html__( 'Description','earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXTAREA,
                'label_block'   => true,
            ]
        );

        $repeater->add_control(
            'bt_icon',
            [
                'label'         => esc_html__( 'Button Icon Class','earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );
        

        $repeater->add_control(
            'bt_text',
            [
                'label'         => esc_html__( 'Button Icon Text','earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $repeater->add_control(
            'bt_link',
            [
                'label'         => esc_html__( 'Button Link', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::URL,
                'placeholder'   => esc_html__( 'https://your-link.com', 'earna-core' ),
                'show_external' => true,
                'default'       => [
                    'url'           => '#',
                    'is_external'   => true,
                    'nofollow'      => true,
                ],
            ]
        );


        $this->add_control(
            'list1',
            [
                'label'     => esc_html__( 'Services', 'earna-core' ),
                'type'      => \Elementor\Controls_Manager::REPEATER,
                'fields'    => $repeater->get_controls(),
                'default'   => [
                    [
                        'list_title' => esc_html__( 'Add services3', 'earna-core' ),
                    ],
                ],
                'title_field' => '{{{ icon_title }}}',
            ]
        );

        $this->end_controls_section();


    }

    /**
     * Render oEmbed widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render() {

        $services3_output = $this->get_settings_for_display(); ?>

       <!-- Star Services Area
============================================= -->
<div class="<?php echo esc_attr($services3_output['class']);?>">
    <!-- Shape -->
    <div class="right-shape">
        <img src="<?php echo esc_url(wp_get_attachment_image_url( $services3_output['img']['id'], 'full' ));?>" alt="Shape">
    </div>
    <!-- Shape -->
    <?php if(!empty($services3_output['title'] || $services3_output['sub'] )): ?>
    <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <div class="site-heading text-center">
                        <h4><?php echo esc_html($services3_output['title']);?></h4>
                        <h2><?php echo esc_html($services3_output['sub']);?></h2>
                        <div class="devider"></div>
                    </div>
                </div>
            </div>
    </div>
    <?php endif;?>
    <div class="container">
        <div class="services-items text-center">
            <div class="row">
                 <?php 
                if(!empty($services3_output['list1'])):
                foreach ($services3_output['list1'] as $services3_slide):?>
                <!-- Single Item -->
                <div class="col-lg-4 col-md-6 single-item">
                    <div class="item" style="background-image: url(<?php echo esc_url($services3_slide['img1']['url']);?>);">
                        <div class="info">
                            <i class="<?php echo esc_attr($services3_slide['icon']);?>"></i>
                            <h4><?php echo esc_html($services3_slide['icon_title']);?></h4>
                            <p>
                                <?php echo esc_html($services3_slide['icon_des']);?>
                            </p>
                            <div class="bottom">
                                <a href="<?php echo esc_url($services3_slide['bt_link']['url']);?>"><i class="<?php echo esc_attr($services3_slide['bt_icon']);?>"></i> <?php echo esc_html($services3_slide['bt_text']);?></a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Single Item -->
                <?php endforeach; endif;?>
                
            </div>
        </div>
    </div>
</div>
<!-- End Services Area -->

    <?php }

}