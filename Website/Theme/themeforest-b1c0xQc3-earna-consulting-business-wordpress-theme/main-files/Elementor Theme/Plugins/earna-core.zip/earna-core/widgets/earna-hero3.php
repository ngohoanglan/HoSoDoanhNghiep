<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Elementor earna hero3 Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class Elementor_earna_hero3_Widget extends \Elementor\Widget_Base {

    /**
     * Get widget name.
     *
     * Retrieve oEmbed widget name.
     *
     * @since 1.0.0
     * @access public
     * @return string Widget name.
     */
    public function get_name() {
        return 'hero3';
    }

    /**
     * Get widget title.
     *
     * Retrieve oEmbed widget title.
     *
     * @since 1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Hero Three Section', 'earna-core' );
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the oEmbed widget belongs to.
     *
     * @since 1.0.0
     * @access public
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'earna' ];
    }

    /**
     * Register oEmbed widget controls.
     *
     * Add input fields to allow the user to customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls() {

        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__( 'Hero 3 Section', 'earna-core' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'bgimg',
            [
                'label'     => esc_html__( 'BG Image', 'earna-core' ),
                'type'      => \Elementor\Controls_Manager::MEDIA,
                'default'   => [
                    'url'       => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'videolink', [
                'label'         => esc_html__( 'BG Video Short Link', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );
        
        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'title', [
                'label'         => esc_html__( 'Title', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $repeater->add_control(
            'sub', [
                'label'         => esc_html__( 'Sub Title', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $repeater->add_control(
            'bttext1', [
                'label'         => esc_html__( 'Button Text', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $repeater->add_control(
            'btlink1',
            [
                'label'         => esc_html__( ' Button Link', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::URL,
                'placeholder'   => esc_html__( 'https://your-link.com', 'earna-core' ),
                'show_external' => true,
                'default'       => [
                    'url'           => '#',
                    'is_external'   => true,
                    'nofollow'      => true,
                ],
            ]
        );

        $this->add_control(
            'list1',
            [
                'label'     => esc_html__( 'Hero Sliders', 'earna-core' ),
                'type'      => \Elementor\Controls_Manager::REPEATER,
                'fields'    => $repeater->get_controls(),
                'default'   => [
                    [
                        'list_title' => esc_html__( 'Add Sliders', 'earna-core' ),
                    ],
                ],
                'title_field' => '{{{ title }}}',
            ]
        );

        $this->end_controls_section();

    }

    /**
     * Render oEmbed widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render() {

        $hero3_output = $this->get_settings_for_display(); ?>

    <!-- Start Banner 
============================================= -->
<div class="banner-area inc-video video-bg-live top-pad-50 bg-cover element-video" style="background-image: url(<?php echo esc_url($hero3_output['bgimg']['url']);?>);">
    <div class="player" data-property="{videoURL:'<?php echo $hero3_output['videolink']; ?>',containment:'.video-bg-live', showControls:false, autoPlay:true, zoom:0, loop:true, mute:true, startAt:3, opacity:1, quality:'default'}"></div>
    
    <div id="bootcarousel" class="carousel text-light slide animate_text" data-ride="carousel">

        <!-- Indicators for slides -->
        <div class="carousel-indicator">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <ol class="carousel-indicators right">
                             <?php 
                                $counter = 0;
                                if(!empty($hero3_output['list1'])):
                                foreach ($hero3_output['list1'] as $hero3_slider):?>
                                <li data-target="#bootcarousel" data-slide-to="<?php echo esc_attr($counter);?>" class="<?php if($counter == 0){echo esc_attr("active");}?>"></li>
                                <?php $counter++; endforeach; endif;?>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <!-- Wrapper for slides -->
        <div class="carousel-inner">
            <?php 
                $counter1 = 0;
                if(!empty($hero3_output['list1'])):
                foreach ($hero3_output['list1'] as $hero3_slider):?>
            <div class="carousel-item <?php if($counter1 == 0){echo esc_attr("active");}?>">
                <div class="box-table shadow dark">
                    <div class="box-cell">
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-8 offset-lg-4">
                                    <div class="content">
                                        <h4 data-animation="animated zoomInRight"><?php echo esc_html($hero3_slider['title']); ?></h4>
                                        <h2 data-animation="animated slideInRight"><?php echo $hero3_slider['sub']; ?></h2>
                                        <a data-animation="animated zoomInUp" class="btn btn-theme effect btn-md" href="<?php echo esc_url($hero3_slider['btlink1']['url']);?>"><?php echo esc_html($hero3_slider['bttext1']); ?></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php $counter1++; endforeach; endif;?>
        </div>
        <!-- End Wrapper for slides -->

    </div>
</div>
<!-- End Banner -->

    <?php }

}