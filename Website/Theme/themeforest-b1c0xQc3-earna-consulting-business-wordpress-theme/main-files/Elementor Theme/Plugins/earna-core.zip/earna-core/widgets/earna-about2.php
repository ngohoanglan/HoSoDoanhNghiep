<?php
if ( ! defined( 'ABSPATH' ) ) {
exit; // Exit if accessed directly.
}

/**
* Elementor earna about2 Widget.
*
* Elementor widget that inserts an embbedable content into the page, from any given URL.
*
* @since 1.0.0
*/
class Elementor_earna_about2_Widget extends \Elementor\Widget_Base {

/**
 * Get widget name.
 *
 * Retrieve oEmbed widget name.
 *
 * @since 1.0.0
 * @access public
 * @return string Widget name.
 */
public function get_name() {
    return 'about2';
}

/**
 * Get widget title.
 *
 * Retrieve oEmbed widget title.
 *
 * @since 1.0.0
 * @access public
 * @return string Widget title.
 */
public function get_title() {
    return esc_html__( 'About Home 4 Section', 'earna-core' );
}

/**
 * Get widget categories.
 *
 * Retrieve the list of categories the oEmbed widget belongs to.
 *
 * @since 1.0.0
 * @access public
 * @return array Widget categories.
 */
public function get_categories() {
    return [ 'earna' ];
}
public function get_script_depends() {
    return array('main');
}   

/**
 * Register oEmbed widget controls.
 *
 * Add input fields to allow the user to customize the widget settings.
 *
 * @since 1.0.0
 * @access protected
 */
protected function register_controls() {

    $this->start_controls_section(
        'content_section',
        [
            'label' => esc_html__( 'About Top Section', 'earna-core' ),
            'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        ]
    );

    $this->add_control(
        'heroimg',
        [
            'label'     => esc_html__( 'Image', 'earna-core' ),
            'type'      => \Elementor\Controls_Manager::MEDIA,
            'default'   => [
                'url'       => \Elementor\Utils::get_placeholder_image_src(),
            ],
        ]
    );

    $this->add_control(
        'heroimg1',
        [
            'label'     => esc_html__( 'Image Two', 'earna-core' ),
            'type'      => \Elementor\Controls_Manager::MEDIA,
            'default'   => [
                'url'       => \Elementor\Utils::get_placeholder_image_src(),
            ],
        ]
    );

    $this->add_control(
        'bgimg',
        [
            'label'     => esc_html__( 'BG Image', 'earna-core' ),
            'type'      => \Elementor\Controls_Manager::MEDIA,
            'default'   => [
                'url'       => \Elementor\Utils::get_placeholder_image_src(),
            ],
        ]
    );

    $this->add_control(
        'title', [
            'label'         => esc_html__( 'Title', 'earna-core' ),
            'type'          => \Elementor\Controls_Manager::TEXT,
            'label_block'   => true,
        ]
    );

    $this->add_control(
        'sub', [
            'label'         => esc_html__( 'Sub Title', 'earna-core' ),
            'type'          => \Elementor\Controls_Manager::TEXT,
            'label_block'   => true,
        ]
    );


    $repeater = new \Elementor\Repeater();

    $repeater->add_control(
        'icon', [
            'label'         => esc_html__( 'Icon Class', 'earna-core' ),
            'type'          => \Elementor\Controls_Manager::TEXT,
            'label_block'   => true,
        ]
    );

    $repeater->add_control(
        'icon_title', [
            'label'         => esc_html__( 'Icon Title', 'earna-core' ),
            'type'          => \Elementor\Controls_Manager::TEXT,
            'label_block'   => true,
        ]
    );

    $repeater->add_control(
        'icon_des', [
            'label'         => esc_html__( 'Icon Description', 'earna-core' ),
            'type'          => \Elementor\Controls_Manager::TEXTAREA,
            'label_block'   => true,
        ]
    );

    $this->add_control(
        'list1',
        [
            'label'     => esc_html__( 'About List', 'earna-core' ),
            'type'      => \Elementor\Controls_Manager::REPEATER,
            'fields'    => $repeater->get_controls(),
            'default'   => [
                [
                    'list_title' => esc_html__( 'Add List', 'earna-core' ),
                ],
            ],
            'title_field' => '{{{ icon_title }}}',
        ]
    );

    $this->end_controls_section();

    $this->start_controls_section(
        'content_section1',
        [
            'label' => esc_html__( 'About Bottom Section', 'earna-core' ),
            'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        ]
    );


    $this->add_control(
        'icon_class', [
            'label'         => esc_html__( 'Icon Class', 'earna-core' ),
            'type'          => \Elementor\Controls_Manager::TEXT,
            'label_block'   => true,
        ]
    );

    $this->add_control(
        'icon_title1', [
            'label'         => esc_html__( 'Icon Title', 'earna-core' ),
            'type'          => \Elementor\Controls_Manager::TEXT,
            'label_block'   => true,
        ]
    );

    $this->add_control(
        'icon_sub1', [
            'label'         => esc_html__( 'Icon Sub Title', 'earna-core' ),
            'type'          => \Elementor\Controls_Manager::TEXT,
            'label_block'   => true,
        ]
    );

    $this->end_controls_section();



}

/**
 * Render oEmbed widget output on the frontend.
 *
 * Written in PHP and used to generate the final HTML.
 *
 * @since 1.0.0
 * @access protected
 */
protected function render() {

    $about2_output = $this->get_settings_for_display(); ?>

    <!-- Start About Area
============================================= -->
<div class="about-content-area default-padding">
    <div class="container">
        <div class="content-box">
            <div class="row">
                <div class="col-lg-6 thumb wow fadeInUp">
                    <div class="thumb-box">
                        <img src="<?php echo esc_url(wp_get_attachment_image_url( $about2_output['heroimg']['id'], 'full' ));?>" alt="Thumb">
                        <img src="<?php echo esc_url(wp_get_attachment_image_url( $about2_output['heroimg1']['id'], 'full' ));?>" alt="Thumb">
                        <div class="shape" style="background-image: url(<?php echo esc_html($about2_output['bgimg']['url']);?>);"></div>
                    </div>
                </div>
                <div class="col-lg-6 info wow fadeInDown">
                    <h2><?php echo esc_html($about2_output['title']);?> <br><?php echo esc_html($about2_output['sub']);?></h2>
                    <ul>
                        <?php 
        if(!empty($about2_output['list1'])):
        foreach ($about2_output['list1'] as $about2_output_list):?>
                        <li>
                            <div class="icon">
                                <i class="<?php echo esc_attr($about2_output_list['icon']);?>"></i>
                            </div>
                            <div class="info">
                                <h4><?php echo esc_html($about2_output_list['icon_title']);?></h4>
                                <p>
                                    <?php echo esc_html($about2_output_list['icon_des']);?>
                                </p>
                            </div>
                        </li>
                        <?php endforeach; endif;?>
                        
                    </ul>
                    <div class="call">
                        <div class="icon">
                            <i class="<?php echo esc_html($about2_output['icon_class']);?>"></i>
                        </div>
                        <div class="intro">
                            <h5><?php echo esc_html($about2_output['icon_title1']);?></h5>
                            <span><?php echo esc_html($about2_output['icon_sub1']);?></span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 center-info">
                    
                </div>
                
            </div>
        </div>
    </div>
</div>
<!-- End About -->

<?php }

}