<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Elementor earna about2 Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class Elementor_earna_service6_Widget extends \Elementor\Widget_Base {

    /**
     * Get widget name.
     *
     * Retrieve oEmbed widget name.
     *
     * @since 1.0.0
     * @access public
     * @return string Widget name.
     */
    public function get_name() {
        return 'service6';
    }

    /**
     * Get widget title.
     *
     * Retrieve oEmbed widget title.
     *
     * @since 1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Home 6 Service Section', 'earna-core' );
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the oEmbed widget belongs to.
     *
     * @since 1.0.0
     * @access public
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'earna' ];
    }
    public function get_script_depends() {
        return array('main');
    }     

    /**
     * Register oEmbed widget controls.
     *
     * Add input fields to allow the user to customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls() {

        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__( 'Service Section Top', 'earna-core' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'title', [
                'label'         => esc_html__( 'Title', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $this->add_control(
            'sub', [
                'label'         => esc_html__( 'Sub Title', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $repeater1 = new \Elementor\Repeater();

        $repeater1->add_control(
            'p_title', [
                'label'         => esc_html__( 'Title', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $repeater1->add_control(
            'p_no', [
                'label'         => esc_html__( 'Number', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $this->add_control(
            'list2',
            [
                'label'     => esc_html__( 'Progress Box', 'earna-core' ),
                'type'      => \Elementor\Controls_Manager::REPEATER,
                'fields'    => $repeater1->get_controls(),
                'default'   => [
                    [
                        'list_title' => esc_html__( 'Add Service Box', 'earna-core' ),
                    ],
                ],
                'title_field' => '{{{ p_title }}}',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'content_section1',
            [
                'label' => esc_html__( 'Service Section', 'earna-core' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'serviceimg',
            [
                'label'     => esc_html__( 'Image', 'tanda-core' ),
                'type'      => \Elementor\Controls_Manager::MEDIA,
                'default'   => [
                    'url'       => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $repeater->add_control(
            'servicetitle', [
                'label'         => esc_html__( 'Title', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $repeater->add_control(
            'servicelink',
            [
                'label'         => esc_html__( 'Link', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::URL,
                'placeholder'   => esc_html__( 'https://your-link.com', 'earna-core' ),
                'show_external' => true,
                'default'       => [
                    'url'           => '#',
                    'is_external'   => true,
                    'nofollow'      => true,
                ],
            ]
        );

        $repeater->add_control(
            'servicedes', [
                'label'         => esc_html__( 'Description', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXTAREA,
                'label_block'   => true,
            ]
        );        

        $this->add_control(
            'list1',
            [
                'label'     => esc_html__( 'Home9 Service Box', 'earna-core' ),
                'type'      => \Elementor\Controls_Manager::REPEATER,
                'fields'    => $repeater->get_controls(),
                'default'   => [
                    [
                        'list_title' => esc_html__( 'Add Service Box', 'earna-core' ),
                    ],
                ],
                'title_field' => '{{{ servicetitle }}}',
            ]
        );

        $this->end_controls_section();


    }

    /**
     * Render oEmbed widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render() {

        $service6_output = $this->get_settings_for_display(); ?>

       <!-- Star Services Area
============================================= -->
<div class="services-style-six-area overflow-hidden default-padding bottom-less bg-gray">

    <div class="shape-box">
        <div class="shape-item"></div>
        <div class="shape-item"></div>
    </div>

    <div class="container">
        <!-- Item Heading -->
        <div class="left-heading">
            <div class="row">
                <div class="col-lg-7 info">
                    <h4><?php echo esc_html($service6_output['title']);?></h4>
                    <h2><?php echo $service6_output['sub'];?></h2>
                </div>
                <div class="col-lg-4 offset-lg-1 right-info">
                    <div class="circle-progress-items">
                        <?php 
    if(!empty($service6_output['list2'])):
    foreach ($service6_output['list2'] as $progress_output_box):?>
                        <div class="circle-progress-item">
                            <div class="progressbar">
                                <div class="circle" data-percent="<?php echo esc_attr($progress_output_box['p_no']);?>">
                                    <strong></strong>
                                </div>
                            </div>
                            <h5><?php echo esc_html($progress_output_box['p_title']);?></h5>
                        </div>
                        <?php endforeach; endif;?>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Item Heading -->
    </div>

    <div class="container">
        <div class="services-style-six-items">
            <div class="row">
            
                <div class="service-six-grid col-lg-6 col-md-6">
                    <?php 
    $counter = 0;
    if(!empty($service6_output['list1'])):
    foreach ($service6_output['list1'] as $service6_output_box):?>
    <?php if($counter == 2){
        echo'</div><div class="service-six-grid col-lg-6 col-md-6">';
    }?>
                    <!-- Single Item -->
                    <div class="services-style-six wow fadeInUp" data-wow-delay="300ms">
                        <div class="item">
                            <div class="info">
                                <img src="<?php echo esc_url(wp_get_attachment_image_url( $service6_output_box['serviceimg']['id'], 'full' ));?>" alt="Icon">
                                <h4><a href="<?php echo esc_url($service6_output_box['servicelink']['url']);?>"><?php echo esc_html($service6_output_box['servicetitle']);?></a></h4>
                                <p>
                                    <?php echo esc_html($service6_output_box['servicedes']);?>
                                </p>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Item -->
                    <?php 
    $counter++;
    endforeach; endif;?>
                </div>

                
            </div>
        </div>
    </div>
</div>
<!-- End Services Area -->

    <?php }

}