<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Elementor earna Hero Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class Elementor_earna_contact_Widget extends \Elementor\Widget_Base {

    /**
     * Get widget name.
     *
     * Retrieve oEmbed widget name.
     *
     * @since 1.0.0
     * @access public
     * @return string Widget name.
     */
    public function get_name() {
        return 'contact';
    }

    /**
     * Get widget title.
     *
     * Retrieve oEmbed widget title.
     *
     * @since 1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Contact Section', 'earna-core' );
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the oEmbed widget belongs to.
     *
     * @since 1.0.0
     * @access public
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'earna' ];
    }

    /**
     * Register oEmbed widget controls.
     *
     * Add input fields to allow the user to customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls() {

        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__( 'Contact - Pages Section', 'earna-core' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'class', [
                'label'         => esc_html__( 'Class', 'earna-core' ),
                'default'         => esc_html__( 'contact-area default-padding bg-theme inc-shape extra-margin', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );


        $this->add_control(
            'title', [
                'label'         => esc_html__( 'Title', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $this->add_control(
            'sub', [
                'label'         => esc_html__( 'Sub Title', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'icon_class', [
                'label'         => esc_html__( 'Icon Class', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $repeater->add_control(
            'icon_des', [
                'label'         => esc_html__( 'Icon Description', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXTAREA,
                'label_block'   => true,
            ]
        );

        $this->add_control(
            'list',
            [
                'label'     => esc_html__( 'Icon List', 'earna-core' ),
                'type'      => \Elementor\Controls_Manager::REPEATER,
                'fields'    => $repeater->get_controls(),
                'default'   => [
                    [
                        'list_title' => esc_html__( 'Add List', 'earna-core' ),
                    ],
                ],
                'title_field' => '{{{ icon_class }}}',
            ]
        );

        $this->add_control(
            'contact_shortcode',
            [
                'label'         => esc_html__( 'Contact Form Shortcode', 'dustra-core' ),
                'type'          => \Elementor\Controls_Manager::TEXTAREA,
                'rows'          => 2,
                'placeholder'   => esc_html__( 'Put your shortcode Here', 'dustra-core' ),
            ]

        );

        $this->add_control(
            'map_src', [
                'label'         => esc_html__( 'Iframe Src', 'tanda-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $this->end_controls_section();



    }

    /**
     * Render oEmbed widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render() {

        $contact_output = $this->get_settings_for_display(); ?>

       <!-- Start Contact Area 
============================================= -->
<div id="contact" class="<?php echo esc_html($contact_output['class']);?>">
    <div class="container">
        <div class="row align-center">
            <div class="col-lg-5 info">
                <div class="content">
                    <h2><?php echo esc_html($contact_output['title']);?></h2>
                    <p><?php echo esc_html($contact_output['sub']);?></p>
                    <ul>
                         <?php 
                        if(!empty($contact_output['list'])):
                        foreach ($contact_output['list'] as $contact_icon):?>
                        <li>
                            <i class="<?php echo esc_attr($contact_icon['icon_class']);?>"></i>
                            <p>
                                <?php echo $contact_icon['icon_des'];?>
                            </p>
                        </li>
                        <?php endforeach; endif;?>
                    </ul>
                </div>
            </div>
            <div class="col-lg-6 offset-lg-1 contact-form-box">
                <div class="form-box">
                    <?php echo do_shortcode($contact_output['contact_shortcode']);?>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Contact Area -->
<?php if(!empty($contact_output['map_src'] )): ?>
<!-- Star Google Maps
    ============================================= -->
    <div class="maps-area">
        <div class="google-maps">
            <iframe src="<?php echo esc_html($contact_output['map_src']);?>"></iframe>
        </div>
    </div>
<!-- End Google Maps -->
<?php endif;?>
    <?php }

}