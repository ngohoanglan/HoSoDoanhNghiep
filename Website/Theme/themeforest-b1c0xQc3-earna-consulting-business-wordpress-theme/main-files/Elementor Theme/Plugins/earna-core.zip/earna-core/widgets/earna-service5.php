<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Elementor earna about2 Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class Elementor_earna_service5_Widget extends \Elementor\Widget_Base {

    /**
     * Get widget name.
     *
     * Retrieve oEmbed widget name.
     *
     * @since 1.0.0
     * @access public
     * @return string Widget name.
     */
    public function get_name() {
        return 'service5';
    }

    /**
     * Get widget title.
     *
     * Retrieve oEmbed widget title.
     *
     * @since 1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Home 5 Service Section', 'earna-core' );
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the oEmbed widget belongs to.
     *
     * @since 1.0.0
     * @access public
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'earna' ];
    }
    public function get_script_depends() {
        return array('main');
    }     

    /**
     * Register oEmbed widget controls.
     *
     * Add input fields to allow the user to customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls() {

        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__( 'Service Section', 'earna-core' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'title', [
                'label'         => esc_html__( 'Title', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $this->add_control(
            'sub', [
                'label'         => esc_html__( 'Sub Title', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'img1',
            [
                'label'     => esc_html__( 'Image', 'earna-core' ),
                'type'      => \Elementor\Controls_Manager::MEDIA,
                'default'   => [
                    'url'       => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );


        $repeater->add_control(
            'servicetitle', [
                'label'         => esc_html__( 'Title', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $repeater->add_control(
            'servicedes', [
                'label'         => esc_html__( 'Description', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXTAREA,
                'label_block'   => true,
            ]
        );

        $repeater->add_control(
            'bticon', [
                'label'         => esc_html__( 'Button Icon Class', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );  

        $repeater->add_control(
            'bttext', [
                'label'         => esc_html__( 'Button Text', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );  


        $repeater->add_control(
            'btlink',
            [
                'label'         => esc_html__( 'Link', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::URL,
                'placeholder'   => esc_html__( 'https://your-link.com', 'earna-core' ),
                'show_external' => true,
                'default'       => [
                    'url'           => '#',
                    'is_external'   => true,
                    'nofollow'      => true,
                ],
            ]
        );   

        $this->add_control(
            'list1',
            [
                'label'     => esc_html__( 'Home5 Service Box', 'earna-core' ),
                'type'      => \Elementor\Controls_Manager::REPEATER,
                'fields'    => $repeater->get_controls(),
                'default'   => [
                    [
                        'list_title' => esc_html__( 'Add Service Box', 'earna-core' ),
                    ],
                ],
                'title_field' => '{{{ servicetitle }}}',
            ]
        );

        $this->end_controls_section();


    }

    /**
     * Render oEmbed widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render() {

        $service5_output = $this->get_settings_for_display(); ?>

       <!-- Star Services Area
============================================= -->
<div class="thumbs-services-area bg-dark text-light default-padding">
    <?php if(!empty($service5_output['title'] )): ?>
    <div class="container">
        <div class="row">
            <div class="col-lg-8 offset-lg-2">
                <div class="site-heading text-center">
                    <h4><?php echo esc_html($service5_output['title']);?></h4>
                    <h2><?php echo esc_html($service5_output['sub']);?></h2>
                    <div class="devider"></div>
                </div>
            </div>
        </div>
    </div>
    <?php endif;?>
    <div class="container">
        <!-- Start Services Items -->
        <div class="services-content">
            <div class="row">
                <div class="col-lg-12">
                    <div class="thumb-services-carousel owl-carousel owl-theme">
                        <?php 
                        if(!empty($service5_output['list1'])):
                        foreach ($service5_output['list1'] as $service5_output_box):?>
                        <!-- Single Item -->
                        <div class="item">
                            <img src="<?php echo esc_url(wp_get_attachment_image_url( $service5_output_box['img1']['id'], 'full' ));?>" alt="Thumb">
                            <div class="info">
                                <h4><a href="<?php echo esc_url($service5_output_box['btlink']['url']);?>"><?php echo esc_html($service5_output_box['servicetitle']);?></a></h4>
                                <p>
                                    <?php echo esc_html($service5_output_box['servicedes']);?>
                                </p>
                                <a href="<?php echo esc_url($service5_output_box['btlink']['url']);?>"><?php echo esc_html($service5_output_box['bttext']);?> <i class="<?php echo esc_attr($service5_output_box['bticon']);?>"></i></a>
                            </div>
                        </div>
                        <!-- End Single Item -->
                        <?php endforeach; endif;?>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Services Items -->
    </div>
</div>
<!-- End Services Area -->

    <?php }

}