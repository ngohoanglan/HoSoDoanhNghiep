<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Elementor earna Hero Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class Elementor_earna_expertise_Widget extends \Elementor\Widget_Base {

    /**
     * Get widget name.
     *
     * Retrieve oEmbed widget name.
     *
     * @since 1.0.0
     * @access public
     * @return string Widget name.
     */
    public function get_name() {
        return 'expertise';
    }

    /**
     * Get widget title.
     *
     * Retrieve oEmbed widget title.
     *
     * @since 1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Expertise - Pages Section', 'earna-core' );
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the oEmbed widget belongs to.
     *
     * @since 1.0.0
     * @access public
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'earna' ];
    }

    /**
     * Register oEmbed widget controls.
     *
     * Add input fields to allow the user to customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls() {

        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__( 'Expertise Progress Bar Section', 'earna-core' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'class', [
                'label'         => esc_html__( 'Class', 'earna-core' ),
                'default'         => esc_html__( 'expertise-area default-padding', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );


        $this->add_control(
            'title', [
                'label'         => esc_html__( 'Title', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $this->add_control(
            'sub', [
                'label'         => esc_html__( 'Sub Title', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'progress_title', [
                'label'         => esc_html__( 'Title', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $repeater->add_control(
            'progress_no', [
                'label'         => esc_html__( 'Percentage', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $this->add_control(
            'list',
            [
                'label'     => esc_html__( 'Progress Bar List', 'earna-core' ),
                'type'      => \Elementor\Controls_Manager::REPEATER,
                'fields'    => $repeater->get_controls(),
                'default'   => [
                    [
                        'list_title' => esc_html__( 'Add List', 'earna-core' ),
                    ],
                ],
                'title_field' => '{{{ progress_title }}}',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'content_section1',
            [
                'label' => esc_html__( 'Expertise Services Section', 'earna-core' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'img1',
            [
                'label'     => esc_html__( 'BG Image', 'earna-core' ),
                'type'      => \Elementor\Controls_Manager::MEDIA,
                'default'   => [
                    'url'       => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'img2',
            [
                'label'     => esc_html__( 'BG Shape', 'earna-core' ),
                'type'      => \Elementor\Controls_Manager::MEDIA,
                'default'   => [
                    'url'       => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $repeater1 = new \Elementor\Repeater();

        $repeater1->add_control(
            'service_title', [
                'label'         => esc_html__( 'Title', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $repeater1->add_control(
            'service_des', [
                'label'         => esc_html__( 'Description', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXTAREA,
                'label_block'   => true,
            ]
        );

        $repeater1->add_control(
            'service_bttext', [
                'label'         => esc_html__( 'Button Text', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $repeater1->add_control(
            'service_btlink',
            [
                'label'         => esc_html__( 'Button Link', 'tanda-core' ),
                'type'          => \Elementor\Controls_Manager::URL,
                'placeholder'   => esc_html__( 'https://your-link.com', 'tanda-core' ),
                'show_external' => true,
                'default'       => [
                    'url'           => '#',
                    'is_external'   => true,
                    'nofollow'      => true,
                ],
            ]
        );

        $this->add_control(
            'list1',
            [
                'label'     => esc_html__( 'Services List', 'earna-core' ),
                'type'      => \Elementor\Controls_Manager::REPEATER,
                'fields'    => $repeater1->get_controls(),
                'default'   => [
                    [
                        'list_title' => esc_html__( 'Add List', 'earna-core' ),
                    ],
                ],
                'title_field' => '{{{ service_title }}}',
            ]
        );

        $this->end_controls_section();



    }

    /**
     * Render oEmbed widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render() {

        $expertise_output = $this->get_settings_for_display(); ?>

       <!-- Start Expertise Area
============================================= -->
<div class="<?php echo esc_html($expertise_output['class']);?>">
    <div class="container">

        <!-- Item Heading -->
        <div class="item-heading">
            <div class="row">
                <div class="col-lg-5 info">
                    <h4><?php echo esc_html($expertise_output['title']);?></h4>
                    <h2><?php echo esc_html($expertise_output['sub']);?></h2>
                </div>
                <div class="col-lg-7 right-info">
                    <div class="skill-items">
                        <?php 
                        if(!empty($expertise_output['list'])):
                        foreach ($expertise_output['list'] as $expertise_progress):?>
                        <!-- Progress Bar Start -->
                        <div class="progress-box">
                            <h5><?php echo esc_html($expertise_progress['progress_title']);?></h5>
                            <div class="progress">
                                <div class="progress-bar" role="progressbar" data-width="<?php echo esc_attr($expertise_progress['progress_no']);?>">
                                    <span><?php echo esc_html($expertise_progress['progress_no']);?>%</span>
                                </div>
                            </div>
                        </div>
                        <!-- End Progressbar -->
                        <?php endforeach; endif;?>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Item Heading -->

        <!-- Expertise Content -->
        <div class="expertise-content text-light" style="background-image: url(<?php echo esc_url($expertise_output['img1']['url']);?>);">
            <div class="row">
                <?php 
                    if(!empty($expertise_output['list1'])):
                    foreach ($expertise_output['list1'] as $expertise_service):?>
                <!-- Single Item -->
                <div class="col-lg-4 single-item">
                    <div class="item">
                        <div class="content">
                            <h4><?php echo esc_html($expertise_service['service_title']);?></h4>
                            <p>
                                 <?php echo esc_html($expertise_service['service_des']);?>
                            </p>
                        </div>
                        <a class="btn btn-sm" href="<?php echo esc_url($expertise_service['service_btlink']['url']);?>"><?php echo esc_html($expertise_service['service_bttext']);?></a>
                    </div>
                </div>
                <!-- End Single Item -->
                <?php endforeach; endif;?>
            </div>
            <!-- Fixed Shape -->
            <div class="fixed-shape" style="background-image: url(<?php echo esc_url($expertise_output['img2']['url']);?>);"></div>
            <!-- Fixed Shape -->
        </div>
        <!-- Expertise Content -->

    </div>
</div>
<!-- End Expertise Area -->
    <?php }

}