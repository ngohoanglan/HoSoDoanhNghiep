<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Elementor Earna about4 Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class Elementor_earna_about4_Widget extends \Elementor\Widget_Base {

    /**
     * Get widget name.
     *
     * Retrieve oEmbed widget name.
     *
     * @since 1.0.0
     * @access public
     * @return string Widget name.
     */
    public function get_name() {
        return 'about4';
    }

    /**
     * Get widget title.
     *
     * Retrieve oEmbed widget title.
     *
     * @since 1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'About - Home 7 Section', 'earna-core' );
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the oEmbed widget belongs to.
     *
     * @since 1.0.0
     * @access public
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'earna' ];
    }

    /**
     * Register oEmbed widget controls.
     *
     * Add input fields to allow the user to customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls() {

        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__( 'About Section Left', 'earna-core' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'class',
            [
                'label'         => esc_html__( 'Class','earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $this->add_control(
            'img',
            [
                'label'     => esc_html__( 'BG Image', 'tanda-core' ),
                'type'      => \Elementor\Controls_Manager::MEDIA,
                'default'   => [
                    'url'       => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'img1',
            [
                'label'     => esc_html__( 'Hero Image', 'tanda-core' ),
                'type'      => \Elementor\Controls_Manager::MEDIA,
                'default'   => [
                    'url'       => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'img2',
            [
                'label'     => esc_html__( 'Hero BG Image', 'tanda-core' ),
                'type'      => \Elementor\Controls_Manager::MEDIA,
                'default'   => [
                    'url'       => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'bticon1',
            [
                'label'         => esc_html__( 'Button Icon Class','earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $this->add_control(
            'btlink1',
            [
                'label'         => esc_html__( 'Button Link', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::URL,
                'placeholder'   => esc_html__( 'https://your-link.com', 'earna-core' ),
                'show_external' => true,
                'default'       => [
                    'url'           => '#',
                    'is_external'   => true,
                    'nofollow'      => true,
                ],
            ]
        );
        

        $this->add_control(
            'bttext2',
            [
                'label'         => esc_html__( 'Button Text','earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $this->add_control(
            'btlink2',
            [
                'label'         => esc_html__( 'Button Link', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::URL,
                'placeholder'   => esc_html__( 'https://your-link.com', 'earna-core' ),
                'show_external' => true,
                'default'       => [
                    'url'           => '#',
                    'is_external'   => true,
                    'nofollow'      => true,
                ],
            ]
        );
        
        $this->end_controls_section();

        $this->start_controls_section(
            'content_section1',
            [
                'label' => esc_html__( 'About Section Right', 'earna-core' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );


        $this->add_control(
            'title',
            [
                'label'         => esc_html__( 'Title','earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );


        $this->add_control(
            'sub',
            [
                'label'         => esc_html__( 'Sub Title','earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $this->add_control(
            'des',
            [
                'label'         => esc_html__( 'Description','earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXTAREA,
                'label_block'   => true,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'list',
            [
                'label'         => esc_html__( 'List','earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );


        $this->add_control(
            'list1',
            [
                'label'     => esc_html__( 'List', 'earna-core' ),
                'type'      => \Elementor\Controls_Manager::REPEATER,
                'fields'    => $repeater->get_controls(),
                'default'   => [
                    [
                        'list_title' => esc_html__( 'Add List', 'earna-core' ),
                    ],
                ],
                'title_field' => '{{{ list }}}',
            ]
        );

        
        $this->add_control(
            'img3',
            [
                'label'     => esc_html__( 'Image', 'tanda-core' ),
                'type'      => \Elementor\Controls_Manager::MEDIA,
                'default'   => [
                    'url'       => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'name',
            [
                'label'         => esc_html__( 'Name','earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $this->add_control(
            'job',
            [
                'label'         => esc_html__( 'Job','earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $this->end_controls_section();


    }

    /**
     * Render oEmbed widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render() {

        $about4_output = $this->get_settings_for_display(); ?>

        <!-- Start About 
============================================= -->
<div class="<?php echo esc_attr($about4_output['class']);?>">
    <div class="shape-left-top">
        <img src="<?php echo esc_url(wp_get_attachment_image_url( $about4_output['img']['id'], 'full' ));?>" alt="Shape">
    </div>
    <div class="container">
        <div class="about-items">
            <div class="row align-center">
                <div class="col-lg-6 about-style-seven">
                    <div class="thumb">
                        <img src="<?php echo esc_url(wp_get_attachment_image_url( $about4_output['img1']['id'], 'full' ));?>" alt="Thumb">
                        <img src="<?php echo esc_url(wp_get_attachment_image_url( $about4_output['img2']['id'], 'full' ));?>" alt="Thumb">
                        <div  href="<?php echo esc_url($about4_output['btlink1']['url']);?>" class="popup-youtube video">
                            <a href="<?php echo esc_url($about4_output['btlink2']['url']);?>"><i class="<?php echo $about4_output['bticon1'];?>"></i> <span><?php echo $about4_output['bttext2'];?></span></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 about-style-seven">
                    <h4><?php echo $about4_output['title'];?></h4>
                    <h2><?php echo $about4_output['sub'];?></h2>
                    <p>
                        <?php echo esc_html($about4_output['des']);?>
                    </p>
                    <ul>
                        <?php 
                        if(!empty($about4_output['list1'])):
                        foreach ($about4_output['list1'] as $about4_slide):?>
                        <li><?php echo $about4_slide['list'];?></li>
                        <?php endforeach; endif;?>
                    </ul>
                    <div class="author">
                        <div class="signature">
                            <img src="<?php echo esc_url(wp_get_attachment_image_url( $about4_output['img3']['id'], 'full' ));?>" alt="signature">
                        </div>
                        <div class="intro">
                            <h5><?php echo esc_html($about4_output['name']);?></h5>
                            <span><?php echo esc_html($about4_output['job']);?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End About Area -->

    <?php }

}