<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Elementor Earna Testimonial Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class Elementor_earna_testimonial_Widget extends \Elementor\Widget_Base {

    /**
     * Get widget name.
     *
     * Retrieve oEmbed widget name.
     *
     * @since 1.0.0
     * @access public
     * @return string Widget name.
     */
    public function get_name() {
        return 'testimonial';
    }

    /**
     * Get widget title.
     *
     * Retrieve oEmbed widget title.
     *
     * @since 1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Testimonial Section', 'earna-core' );
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the oEmbed widget belongs to.
     *
     * @since 1.0.0
     * @access public
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'earna' ];
    }
    public function get_script_depends() {
        return array('main');
    }  

    /**
     * Register oEmbed widget controls.
     *
     * Add input fields to allow the user to customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls() {

        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__( 'Testimonial Section', 'earna-core' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
        
        $this->add_control(
            'class', [
                'label'         => esc_html__( 'Class', 'earna-core' ),
                'default'         => esc_html__( 'testimonials-area bg-gray default-padding-bottom', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,

            ]
        );
        
        $this->add_control(
            'heading', [
                'label'         => esc_html__( 'Heading', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,

            ]
        );

        $this->add_control(
            'title', [
                'label'         => esc_html__( 'Title', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,

            ]
        );

        $this->add_control(
            'description', [
                'label'         => esc_html__( 'Description', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXTAREA,
                'label_block'   => true,

            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'img1',
            [
                'label'     => esc_html__( 'Hero Image', 'earna-core' ),
                'type'      => \Elementor\Controls_Manager::MEDIA,
                'default'   => [
                    'url'       => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $repeater->add_control(
            'des',
            [
                'label'         => esc_html__( 'Description','earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXTAREA,
                'label_block'   => true,
            ]
        );

        $repeater->add_control(
            'name',
            [
                'label'         => esc_html__( 'Name','earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $repeater->add_control(
            'job',
            [
                'label'         => esc_html__( 'Job','earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );


        $this->add_control(
            'list1',
            [
                'label'     => esc_html__( 'Testimonial', 'earna-core' ),
                'type'      => \Elementor\Controls_Manager::REPEATER,
                'fields'    => $repeater->get_controls(),
                'default'   => [
                    [
                        'list_title' => esc_html__( 'Add Testimonial', 'earna-core' ),
                    ],
                ],
                'title_field' => '{{{ name }}}',
            ]
        );

        $this->end_controls_section();

    }

    /**
     * Render oEmbed widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render() {

        $testimonial_output = $this->get_settings_for_display(); ?>

        <!-- Star testimonials Area
    ============================================= -->
    <div class="<?php echo esc_html($testimonial_output['class']); ?>">
        <!-- Fixed Shape -->
        <div class="fixed-shape" style="background-image: url(<?php echo esc_url(get_template_directory_uri() . '/img/shape/10.png'); ?>);"></div>
        <!-- End Fixed Shape -->
        <div class="container">
            <div class="testimonial-items">
                <div class="row align-center">
                    <div class="col-lg-7 testimonials-content">
                        <div class="testimonials-carousel owl-carousel owl-theme">
                            <?php 
                            if(!empty($testimonial_output['list1'])):
                            foreach ($testimonial_output['list1'] as $testimonial_slider):?>
                            <!-- Single Item -->
                            <div class="item">
                                <div class="info">
                                    <p>
                                        <?php echo esc_html($testimonial_slider['des']);?>
                                    </p>
                                    <div class="provider">
                                        <div class="thumb">
                                            <img src="<?php echo esc_url(wp_get_attachment_image_url( $testimonial_slider['img1']['id'], 'full' ));?>" alt="Author">
                                        </div>
                                        <div class="content">
                                            <h4><?php echo esc_html($testimonial_slider['name']);?></h4>
                                            <span><?php echo esc_html($testimonial_slider['job']);?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Item -->
                            <?php endforeach; endif;?>
                        </div>
                    </div>
                    <div class="col-lg-5 info">
                        <h4><?php echo esc_html($testimonial_output['heading']); ?></h4>
                        <h2><?php echo esc_html($testimonial_output['title']); ?></h2>
                        <p>
                            <?php echo esc_html($testimonial_output['description']); ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End testimonials Area -->
</div>
<!-- End Overflow Hidden Box -->
       

    <?php }

}