<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Elementor Earna about3 Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class Elementor_earna_about3_Widget extends \Elementor\Widget_Base {

    /**
     * Get widget name.
     *
     * Retrieve oEmbed widget name.
     *
     * @since 1.0.0
     * @access public
     * @return string Widget name.
     */
    public function get_name() {
        return 'about3';
    }

    /**
     * Get widget title.
     *
     * Retrieve oEmbed widget title.
     *
     * @since 1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Home 6 About Section', 'earna-core' );
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the oEmbed widget belongs to.
     *
     * @since 1.0.0
     * @access public
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'earna' ];
    }

    /**
     * Register oEmbed widget controls.
     *
     * Add input fields to allow the user to customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls() {

        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__( 'About Three Section Left', 'earna-core' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'class',
            [
                'label'         => esc_html__( 'Class','earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $this->add_control(
            'bgimg',
            [
                'label'     => esc_html__( 'BG Image', 'tanda-core' ),
                'type'      => \Elementor\Controls_Manager::MEDIA,
                'default'   => [
                    'url'       => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'img',
            [
                'label'     => esc_html__( 'Image', 'tanda-core' ),
                'type'      => \Elementor\Controls_Manager::MEDIA,
                'default'   => [
                    'url'       => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );
        
       $repeater = new \Elementor\Repeater();

       $repeater->add_control(
            'icon_img',
            [
                'label'     => esc_html__( 'Image', 'tanda-core' ),
                'type'      => \Elementor\Controls_Manager::MEDIA,
                'default'   => [
                    'url'       => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $repeater->add_control(
            'icon_title',
            [
                'label'         => esc_html__( 'Icon Title','earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $repeater->add_control(
            'icon_des',
            [
                'label'         => esc_html__( 'Description','earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXTAREA,
                'label_block'   => true,
            ]
        );

        
        $this->add_control(
            'list1',
            [
                'label'     => esc_html__( 'Icon List', 'earna-core' ),
                'type'      => \Elementor\Controls_Manager::REPEATER,
                'fields'    => $repeater->get_controls(),
                'default'   => [
                    [
                        'list_title' => esc_html__( 'Add about3 List', 'earna-core' ),
                    ],
                ],
                'title_field' => '{{{ icon_title }}}',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'content_section1',
            [
                'label' => esc_html__( 'about3 Section Right', 'earna-core' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
        
       
        $this->add_control(
            'title',
            [
                'label'         => esc_html__( 'Title','earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $this->add_control(
            'des',
            [
                'label'         => esc_html__( 'Description','earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXTAREA,
                'label_block'   => true,
            ]
        );

        $this->add_control(
            'img1',
            [
                'label'     => esc_html__( 'Image', 'tanda-core' ),
                'type'      => \Elementor\Controls_Manager::MEDIA,
                'default'   => [
                    'url'       => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'name',
            [
                'label'         => esc_html__( 'Name','earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $this->add_control(
            'job',
            [
                'label'         => esc_html__( 'Job','earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $this->end_controls_section();


    }

    /**
     * Render oEmbed widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render() {

        $about3_output = $this->get_settings_for_display(); ?>

       <!-- Star About Area
============================================= -->
<div class="<?php echo esc_html($about3_output['class']);?>">
    <div class="container">
        <div class="row align-center">
            <div class="col-lg-7">
                <div class="about-style-six d-flex">
                    <div class="shape-inner">
                        <img src="<?php echo esc_url(wp_get_attachment_image_url( $about3_output['bgimg']['id'], 'full' ));?>" alt="Shape">
                    </div>
                    <div class="thumb">
                        <img src="<?php echo esc_url(wp_get_attachment_image_url( $about3_output['img']['id'], 'full' ));?>" alt="Thumb">
                    </div>
                    <ul class="about-service-list text-light">
                        <?php 
                if(!empty($about3_output['list1'])):
                foreach ($about3_output['list1'] as $about3_list):?>
                        <li>
                            <div class="icon">
                                <img src="<?php echo esc_url(wp_get_attachment_image_url( $about3_list['icon_img']['id'], 'full' ));?>" alt="Thumb">
                            </div>
                            <div class="content">
                                <h4><?php echo esc_html($about3_list['icon_title']);?></h4>
                                <p>
                                    <?php echo esc_html($about3_list['icon_des']);?>
                                </p>
                            </div>
                        </li>
                        <?php endforeach; endif;?>
                        
                    </ul>
                </div>
            </div>
            <div class="col-lg-4 about-style-six-info offset-lg-1">
                <h2 class="title"><?php echo esc_html($about3_output['title']);?></h2>
                <p>
                    <?php echo esc_html($about3_output['des']);?>
                </p>
                <div class="compnay-author">
                    <div class="thumb">
                        <img src="<?php echo esc_url(wp_get_attachment_image_url( $about3_output['img1']['id'], 'full' ));?>" alt="Thumb">
                    </div>
                    <div class="content">
                        <h4><?php echo esc_html($about3_output['name']);?></h4>
                        <span><?php echo $about3_output['job'];?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End About -->

    <?php }

}