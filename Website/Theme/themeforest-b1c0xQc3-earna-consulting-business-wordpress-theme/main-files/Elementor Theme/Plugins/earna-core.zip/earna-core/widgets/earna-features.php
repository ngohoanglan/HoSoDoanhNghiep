<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Elementor Earna Features Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class Elementor_earna_features_Widget extends \Elementor\Widget_Base {

    /**
     * Get widget name.
     *
     * Retrieve oEmbed widget name.
     *
     * @since 1.0.0
     * @access public
     * @return string Widget name.
     */
    public function get_name() {
        return 'features';
    }

    /**
     * Get widget title.
     *
     * Retrieve oEmbed widget title.
     *
     * @since 1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Features Section', 'earna-core' );
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the oEmbed widget belongs to.
     *
     * @since 1.0.0
     * @access public
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'earna' ];
    }

    /**
     * Register oEmbed widget controls.
     *
     * Add input fields to allow the user to customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls() {

        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__( 'Features Section', 'earna-core' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
        
        $this->add_control(
            'class',
            [
                'label'         => esc_html__( 'Class','earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $this->add_control(
            'title',
            [
                'label'         => esc_html__( 'Title','earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $this->add_control(
            'sub',
            [
                'label'         => esc_html__( 'Sub Title','earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );
        
       $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'icon',
            [
                'label'         => esc_html__( 'Icon Class','earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $repeater->add_control(
            'no',
            [
                'label'         => esc_html__( 'Number','earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $repeater->add_control(
            'title1',
            [
                'label'         => esc_html__( 'Title','earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $repeater->add_control(
            'des',
            [
                'label'         => esc_html__( 'Description','earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXTAREA,
                'label_block'   => true,
            ]
        );

        $repeater->add_control(
            'bt_icon',
            [
                'label'         => esc_html__( 'Button Icon Class','earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $repeater->add_control(
            'bt_link',
            [
                'label'         => esc_html__( 'Button Link', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::URL,
                'placeholder'   => esc_html__( 'https://your-link.com', 'earna-core' ),
                'show_external' => true,
                'default'       => [
                    'url'           => '#',
                    'is_external'   => true,
                    'nofollow'      => true,
                ],
            ]
        );

        

        $this->add_control(
            'list1',
            [
                'label'     => esc_html__( 'Features', 'earna-core' ),
                'type'      => \Elementor\Controls_Manager::REPEATER,
                'fields'    => $repeater->get_controls(),
                'default'   => [
                    [
                        'list_title' => esc_html__( 'Add Features', 'earna-core' ),
                    ],
                ],
                'title_field' => '{{{ title1 }}}',
            ]
        );

        $this->end_controls_section();


    }

    /**
     * Render oEmbed widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render() {

        $features_output = $this->get_settings_for_display(); ?>

        <!-- Star Work Process Area
    ============================================= -->
    <div class="<?php echo esc_attr($features_output['class']);?>">
        <?php if(!empty($features_output['title'] || $features_output['sub'] )): ?>
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <div class="site-heading text-center">
                        <h4><?php echo esc_html($features_output['title']);?></h4>
                        <h2><?php echo esc_html($features_output['sub']);?></h2>
                        <div class="devider"></div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif;?>
        <div class="container">
            <div class="work-process-items features-content">
                <div class="row">

        <?php 
                if(!empty($features_output['list1'])):
                foreach ($features_output['list1'] as $features_slide):?>

                <!-- Single Item -->
                <div class="single-item col-lg-4 col-md-6">
                    <div class="item">
                        <i class="<?php echo esc_attr($features_slide['icon']);?>"></i>
                        <div class="top">
                            <span><?php echo esc_html($features_slide['no']);?></span>
                            <h4><?php echo esc_html($features_slide['title1']);?></h4>
                        </div>
                        <p>
                            <?php echo esc_html($features_slide['des']);?>
                        </p>
                        <a href="<?php echo esc_url($features_slide['bt_link']['url']);?>"><i class="<?php echo esc_attr($features_slide['bt_icon']);?>"></i></a>
                    </div>
                </div>
                <!-- Single Item -->

        <?php endforeach; endif;?>

        </div>
            </div>
        </div>
    </div>
    <!-- End Features Area -->

    <?php }

}