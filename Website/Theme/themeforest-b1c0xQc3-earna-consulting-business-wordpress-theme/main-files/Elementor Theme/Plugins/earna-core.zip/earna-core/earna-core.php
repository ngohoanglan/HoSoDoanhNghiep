<?php
/**
 * Plugin Name: Earna Core
 * Description: earna Core Plugin Contains Elementor Widgets Specifically created for earna WordPress Theme.
 * Plugin URI:  wordpressriverthemes.com/earna-elem
 * Version:     1.1
 * Author:      WordPressRiver
 * Author URI:  https://themeforest.net/user/wordpressriver/portfolio
 * Text Domain: earna-core
 *
 * Elementor tested up to: 3.5.0
 * Elementor Pro tested up to: 3.5.0
 */


if ( !defined('ABSPATH') )
    die('-1');

// Make sure the same class is not loaded twice in free/premium versions.
if ( !class_exists( 'earna_core' ) ) {
	/**
	 * Main earna Core Class
	 *
	 * The main class that initiates and runs the earna Core plugin.
	 *
	 * @since 1.7.0
	 */
	final class earna_core {
		/**
		 * earna Core Version
		 *
		 * Holds the version of the plugin.
		 *
		 * @since 1.7.0
		 * @since 1.7.1 Moved from property with that name to a constant.
		 *
		 * @var string The plugin version.
		 */
		const VERSION = '1.0' ;
		/**
		 * Minimum Elementor Version
		 *
		 * Holds the minimum Elementor version required to run the plugin.
		 *
		 * @since 1.7.0
		 * @since 1.7.1 Moved from property with that name to a constant.
		 *
		 * @var string Minimum Elementor version required to run the plugin.
		 */
		const MINIMUM_ELEMENTOR_VERSION = '1.7.0';
		/**
		 * Minimum PHP Version
		 *
		 * Holds the minimum PHP version required to run the plugin.
		 *
		 * @since 1.7.0
		 * @since 1.7.1 Moved from property with that name to a constant.
		 *
		 * @var string Minimum PHP version required to run the plugin.
		 */
		const  MINIMUM_PHP_VERSION = '5.4' ;
        /**
         * Plugin's directory paths
         * @since 1.0
         */
        const CSS = null;
        const JS = null;
        const IMG = null;
        const VEND = null;

		/**
		 * Instance
		 *
		 * Holds a single instance of the `earna_core` class.
		 *
		 * @since 1.7.0
		 *
		 * @access private
		 * @static
		 *
		 * @var earna_core A single instance of the class.
		 */
		private static  $_instance = null ;
		/**
		 * Instance
		 *
		 * Ensures only one instance of the class is loaded or can be loaded.
		 *
		 * @since 1.7.0
		 *
		 * @access public
		 * @static
		 *
		 * @return earna_core An instance of the class.
		 */
		public static function instance() {
			if ( is_null( self::$_instance ) ) {
				self::$_instance = new self();
			}
			return self::$_instance;
		}

		/**
		 * Clone
		 *
		 * Disable class cloning.
		 *
		 * @since 1.7.0
		 *
		 * @access protected
		 *
		 * @return void
		 */
		public function __clone() {
			// Cloning instances of the class is forbidden
			_doing_it_wrong( __FUNCTION__, esc_html__( 'Cheatin&#8217; huh?', 'earna-core' ), '1.7.0' );
		}

		/**
		 * Wakeup
		 *
		 * Disable unserializing the class.
		 *
		 * @since 1.7.0
		 *
		 * @access protected
		 *
		 * @return void
		 */
		public function __wakeup() {
			// Unserializing instances of the class is forbidden.
			_doing_it_wrong( __FUNCTION__, esc_html__( 'Cheatin&#8217; huh?', 'earna-core' ), '1.7.0' );
		}

		/**
		 * Constructor
		 *
		 * Initialize the earna Core plugins.
		 *
		 * @since 1.7.0
		 *
		 * @access public
		 */
		public function __construct() {
			$this->core_includes();
			$this->init_hooks();
			do_action( 'earna_core_loaded' );
		}

		/**
		 * Include Files
		 *
		 * Load core files required to run the plugin.
		 *
		 * @since 1.7.0
		 *
		 * @access public
		 */
		public function core_includes() {
		
		}

		/**
		 * Init Hooks
		 *
		 * Hook into actions and filters.
		 *
		 * @since 1.7.0
		 *
		 * @access private
		 */
		private function init_hooks() {
			add_action( 'init', [ $this, 'i18n' ] );
			add_action( 'plugins_loaded', [ $this, 'init' ] );
		}

		/**
		 * Load Textdomain
		 *
		 * Load plugin localization files.
		 *
		 * @since 1.7.0
		 *
		 * @access public
		 */
		public function i18n() {
			load_plugin_textdomain( 'earna-core', false, plugin_basename( dirname( __FILE__ ) ) . '/languages' );
		}



		/**
		 * Init earna Core
		 *
		 * Load the plugin after Elementor (and other plugins) are loaded.
		 *
		 * @since 1.0.0
		 * @since 1.7.0 The logic moved from a searnalone function to this class method.
		 *
		 * @access public
		 */
		public function init() {

			if ( !did_action( 'elementor/loaded' ) ) {
				add_action( 'admin_notices', [ $this, 'admin_notice_missing_main_plugin' ] );
				return;
			}

			// Check for required Elementor version

			if ( !version_compare( ELEMENTOR_VERSION, self::MINIMUM_ELEMENTOR_VERSION, '>=' ) ) {
				add_action( 'admin_notices', [ $this, 'admin_notice_minimum_elementor_version' ] );
				return;
			}

			// Check for required PHP version

			if ( version_compare( PHP_VERSION, self::MINIMUM_PHP_VERSION, '<' ) ) {
				add_action( 'admin_notices', [ $this, 'admin_notice_minimum_php_version' ] );
				return;
			}

			// Add new Elementor Categories
			add_action( 'elementor/init', [ $this, 'add_elementor_category' ] );

			// Register Widget Styles
			add_action( 'elementor/frontend/after_enqueue_styles', [ $this, 'enqueue_widget_styles' ] );
			add_action( 'elementor/editor/before_enqueue_scripts', [ $this, 'enqueue_widget_styles' ] );

			// Register Widget Scripts
			add_action( 'elementor/frontend/after_register_scripts', [ $this,'register_widget_scripts' ] );
			add_action( 'elementor/editor/before_enqueue_scripts', [ $this, 'register_widget_scripts' ] );

			// Register New Widgets
			add_action( 'elementor/widgets/widgets_registered', [ $this, 'on_widgets_registered' ] );
		}

		/**
		 * Admin notice
		 *
		 * Warning when the site doesn't have Elementor installed or activated.
		 *
		 * @since 1.1.0
		 * @since 1.7.0 Moved from a searnalone function to a class method.
		 *
		 * @access public
		 */
		public function admin_notice_missing_main_plugin() {
			$message = sprintf(
			/* translators: 1: earna Core 2: Elementor */
				esc_html__( '"%1$s" requires "%2$s" to be installed and activated.', 'earna-core' ),
				'<strong>' . esc_html__( 'earna core', 'earna-core' ) . '</strong>',
				'<strong>' . esc_html__( 'Elementor', 'earna-core' ) . '</strong>'
			);
			printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );
		}

		/**
		 * Admin notice
		 *
		 * Warning when the site doesn't have a minimum required Elementor version.
		 *
		 * @since 1.1.0
		 * @since 1.7.0 Moved from a searnalone function to a class method.
		 *
		 * @access public
		 */
		public function admin_notice_minimum_elementor_version() {
			$message = sprintf(
			/* translators: 1: earna Core 2: Elementor 3: Required Elementor version */
				esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'earna-core' ),
				'<strong>' . esc_html__( 'earna Core', 'earna-core' ) . '</strong>',
				'<strong>' . esc_html__( 'Elementor', 'earna-core' ) . '</strong>',
				self::MINIMUM_ELEMENTOR_VERSION
			);
			printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );
		}

		/**
		 * Admin notice
		 *
		 * Warning when the site doesn't have a minimum required PHP version.
		 *
		 * @since 1.7.0
		 *
		 * @access public
		 */
		public function admin_notice_minimum_php_version() {
			$message = sprintf(
			/* translators: 1: earna Core 2: PHP 3: Required PHP version */
				esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'earna-core' ),
				'<strong>' . esc_html__( 'earna Core', 'earna-core' ) . '</strong>',
				'<strong>' . esc_html__( 'PHP', 'earna-core' ) . '</strong>',
				self::MINIMUM_PHP_VERSION
			);
			printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );
		}

		/**
		 * Add new Elementor Categories
		 *
		 * Register new widget categories for earna Core widgets.
		 *
		 * @since 1.0.0
		 * @since 1.7.1 The method moved to this class.
		 *
		 * @access public
		 */
		public function add_elementor_category() {
			\Elementor\Plugin::instance()->elements_manager->add_category( 'earna', [
				'title' => __( 'earna Elements', 'earna-core' ),
			], 1 );
		}


		/**
		 * Register Widget Scripts
		 *
		 * Register custom scripts required to run Saasland Core.
		 *
		 * @since 1.6.0
		 * @since 1.7.1 The method moved to this class.
		 *
		 * @access public
		 */
		public function register_widget_scripts() {
			wp_register_script( 'main', plugins_url( '/assets/js/main.js', __FILE__ ), array( 'jquery' ), false, true );
		}




		/**
		 * Register Widget Styles
		 *
		 * Register custom styles required to run Saasland Core.
		 *
		 * @since 1.7.0
		 * @since 1.7.1 The method moved to this class.
		 *
		 * @access public
		 */
		
		public function enqueue_widget_styles() {

		}

		/**
		 * Register New Widgets
		 *
		 * Include earna Core widgets files and register them in Elementor.
		 *
		 * @since 1.0.0
		 * @since 1.7.1 The method moved to this class.
		 *
		 * @access public
		 */
		public function on_widgets_registered() {
			$this->include_widgets();
			$this->register_widgets();
		}

		/**
		 * Include Widgets Files
		 *
		 * Load earna Core widgets files.
		 *
		 * @since 1.0.0
		 * @since 1.7.1 The method moved to this class.
		 *
		 * @access private
		 */
		private function include_widgets() {
		    
		    // Home 1
					
			require_once( __DIR__ . '/widgets/earna-hero.php' );
			
			require_once( __DIR__ . '/widgets/earna-features.php' );
			
			require_once( __DIR__ . '/widgets/earna-about.php' );
			
			require_once( __DIR__ . '/widgets/earna-services.php' );
			
			require_once( __DIR__ . '/widgets/earna-choose.php' );
			
			require_once( __DIR__ . '/widgets/earna-client.php' );
			
			require_once( __DIR__ . '/widgets/earna-team.php' );
			
			require_once( __DIR__ . '/widgets/earna-testimonial.php' );
			
			require_once( __DIR__ . '/widgets/earna-case.php' );
			
			require_once( __DIR__ . '/widgets/earna-blog.php' );
			
			// Pages
			
			    // About Us
			       
			    require_once( __DIR__ . '/widgets/pages/earna-about1.php' );
			    
			    require_once( __DIR__ . '/widgets/pages/earna-growth.php' );
			    
			    // Team Single
			    
			    require_once( __DIR__ . '/widgets/earna-teamsingle.php' );
			    
			    // Faq
			    
			    require_once( __DIR__ . '/widgets/pages/earna-faq.php' );
			    
			    // Contact
			    
			    require_once( __DIR__ . '/widgets/pages/earna-contact.php' );
			    
	    // Services
	        
	        // Service One
	        
	         require_once( __DIR__ . '/widgets/services/earna-expertise.php' );
	         
	         // Service Two
	        
	         require_once( __DIR__ . '/widgets/services/earna-services2.php' );
	         
	         // Service Three
	        
	         require_once( __DIR__ . '/widgets/services/earna-services3.php' );
	         
	         // Service Single 
	         
	         require_once( __DIR__ . '/widgets/services/earna-servicesingle.php' );
	         
	   // Case Studies
	        
	         require_once( __DIR__ . '/widgets/pages/earna-case1.php' );
	         
	         require_once( __DIR__ . '/widgets/pages/earna-casesingle.php' );
	         
	    // Home 2
					
			require_once( __DIR__ . '/widgets/earna-hero2.php' );
			
			require_once( __DIR__ . '/widgets/earna-faq1.php' );
			
		// Home 3
					
			require_once( __DIR__ . '/widgets/earna-hero3.php' );
			
			require_once( __DIR__ . '/widgets/earna-service4.php' );
			
		// Home 4
					
			require_once( __DIR__ . '/widgets/earna-hero4.php' );
			
			require_once( __DIR__ . '/widgets/earna-about2.php' );
			
		// Home 5
					
			require_once( __DIR__ . '/widgets/earna-hero5.php' );
			
			require_once( __DIR__ . '/widgets/earna-service5.php' );
			
		// Home 6
					
			require_once( __DIR__ . '/widgets/earna-hero6.php' );
			
			require_once( __DIR__ . '/widgets/earna-about3.php' );
			
			require_once( __DIR__ . '/widgets/earna-service6.php' );
			
			require_once( __DIR__ . '/widgets/earna-testimonial2.php' );
			
		// Home 7
					
			require_once( __DIR__ . '/widgets/earna-hero7.php' );
			
			require_once( __DIR__ . '/widgets/earna-service7.php' );
			
			require_once( __DIR__ . '/widgets/earna-about4.php' );
			
			require_once( __DIR__ . '/widgets/earna-process.php' );
			    
			    
			    

		    

        }
			
		/**
		 * Register Widgets
		 *
		 * Register earna Core widgets.
		 *
		 * @since 1.0.0
		 * @since 1.7.1 The method moved to this class.
		 *
		 * @access private
		 */
		private function register_widgets() {

			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor_earna_hero_Widget() );
			
			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor_earna_features_Widget() );
			
			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor_earna_about_Widget() );
			
			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor_earna_services_Widget() );
			
			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor_earna_choose_Widget() );
			
			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor_earna_client_Widget() );
			
			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor_earna_team_Widget() );
			
			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor_earna_testimonial_Widget() );
			
			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor_earna_case_Widget() );
			
			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor_earna_blog_Widget() );
			
			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor_earna_about1_Widget() );
			
			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor_earna_growth_Widget() );
			
			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor_earna_teamsingle_Widget() );
			
			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor_earna_faq_Widget() );
			
			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor_earna_contact_Widget() );
			
			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor_earna_expertise_Widget() );
			
			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor_earna_services2_Widget() );
			
			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor_earna_services3_Widget() );
			
			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor_earna_case1_Widget() );
			
			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor_earna_servicesingle_Widget() );
			
			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor_earna_casesingle_Widget() );
			
			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor_earna_hero2_Widget() );
			
			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor_earna_faq1_Widget() );
			
			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor_earna_hero3_Widget() );
			
			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor_earna_service4_Widget() );
			
			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor_earna_hero4_Widget() );
			
			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor_earna_about2_Widget() );
			
			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor_earna_hero5_Widget() );
			
			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor_earna_service5_Widget() );
			
			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor_earna_hero6_Widget() );
			
			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor_earna_about3_Widget() );
            
            \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor_earna_service6_Widget() );
            
            \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor_earna_testimonial2_Widget() );
            
            \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor_earna_hero7_Widget() );
            
            \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor_earna_service7_Widget() );
            
            \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor_earna_about4_Widget() );
            
            \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor_earna_process_Widget() );

			
			
		}
	}
} 
// Make sure the same function is not loaded twice in free/premium versions.

if ( !function_exists( 'earna_core_load' ) ) {
	/**
	 * Load earna Core
	 *
	 * Main instance of earna_core.
	 *
	 * @since 1.0.0
	 * @since 1.7.0 The logic moved from this function to a class method.
	 */
	function earna_core_load() {
		return earna_core::instance();
	}

	// Run earna Core
    earna_core_load();
}