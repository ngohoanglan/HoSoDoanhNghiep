<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Elementor earna Hero Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class Elementor_earna_casesingle_Widget extends \Elementor\Widget_Base {

    /**
     * Get widget name.
     *
     * Retrieve oEmbed widget name.
     *
     * @since 1.0.0
     * @access public
     * @return string Widget name.
     */
    public function get_name() {
        return 'casesingle';
    }

    /**
     * Get widget title.
     *
     * Retrieve oEmbed widget title.
     *
     * @since 1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Case Single Section', 'earna-core' );
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the oEmbed widget belongs to.
     *
     * @since 1.0.0
     * @access public
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'earna' ];
    }

    /**
     * Register oEmbed widget controls.
     *
     * Add input fields to allow the user to customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls() {

        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__( 'Case Single Section', 'earna-core' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
        
        $this->add_control(
            'img1',
            [
                'label'     => esc_html__( 'Hero Image', 'earna-core' ),
                'type'      => \Elementor\Controls_Manager::MEDIA,
                'default'   => [
                    'url'       => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'title', [
                'label'         => esc_html__( 'Title', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $this->add_control(
            'des', [
                'label'         => esc_html__( 'Description', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXTAREA,
                'label_block'   => true,
            ]
        );

        $this->add_control(
            'des1', [
                'label'         => esc_html__( 'Description Two', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXTAREA,
                'label_block'   => true,
            ]
        );

        $this->add_control(
            'info_title', [
                'label'         => esc_html__( 'Info Title', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'icon_title', [
                'label'         => esc_html__( 'Title', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $repeater->add_control(
            'icon_des', [
                'label'         => esc_html__( 'Description', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXTAREA,
                'label_block'   => true,
            ]
        );

        $this->add_control(
            'list',
            [
                'label'     => esc_html__( 'List', 'earna-core' ),
                'type'      => \Elementor\Controls_Manager::REPEATER,
                'fields'    => $repeater->get_controls(),
                'default'   => [
                    [
                        'list_title' => esc_html__( 'Add List', 'earna-core' ),
                    ],
                ],
                'title_field' => '{{{ icon_title }}}',
            ]
        );

        $this->add_control(
            'details_case', [
                'label'         => esc_html__( 'Details', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::WYSIWYG,
                'label_block'   => true,
            ]
        );

        $this->add_control(
            'img2',
            [
                'label'     => esc_html__( 'Image One', 'earna-core' ),
                'type'      => \Elementor\Controls_Manager::MEDIA,
                'default'   => [
                    'url'       => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'img3',
            [
                'label'     => esc_html__( 'Image Two', 'earna-core' ),
                'type'      => \Elementor\Controls_Manager::MEDIA,
                'default'   => [
                    'url'       => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'content_section2',
            [
                'label' => esc_html__( 'Case Single Social Media', 'earna-core' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'social_title', [
                'label'         => esc_html__( 'Social Title', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $repeater1 = new \Elementor\Repeater();

        $repeater1->add_control(
            'social_class', [
                'label'         => esc_html__( 'Class', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $repeater1->add_control(
            'social_icon', [
                'label'         => esc_html__( 'Icon Class', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );


        $repeater1->add_control(
            'social_link',
            [
                'label'         => esc_html__( 'Link', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::URL,
                'placeholder'   => esc_html__( 'https://your-link.com', 'earna-core' ),
                'show_external' => true,
                'default'       => [
                    'url'           => '#',
                    'is_external'   => true,
                    'nofollow'      => true,
                ],
            ]
        );

        $this->add_control(
            'list1',
            [
                'label'     => esc_html__( 'Social Media', 'earna-core' ),
                'type'      => \Elementor\Controls_Manager::REPEATER,
                'fields'    => $repeater1->get_controls(),
                'default'   => [
                    [
                        'list_title' => esc_html__( 'Add Social', 'earna-core' ),
                    ],
                ],
                'title_field' => '{{{ social_icon }}}',
            ]
        );

        $this->end_controls_section();

    

    }

    /**
     * Render oEmbed widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render() {

        $casesingle_output = $this->get_settings_for_display(); ?>

        <!-- Star Project Details Area
============================================= -->
<div class="project-details-area default-padding">
    <div class="container">
        <div class="project-details-items">
            <div class="thumb">
                <img src="<?php echo esc_url(wp_get_attachment_image_url( $casesingle_output['img1']['id'], 'full' ));?>" alt="Thumb">
            </div>
            <div class="top-info">
                <div class="row">
                    <div class="col-lg-7 left-info">
                        <h2><?php echo esc_html($casesingle_output['title']);?></h2>
                        <p>
                            <?php echo esc_html($casesingle_output['des']);?>
                        </p>
                        <p>
                           <?php echo esc_html($casesingle_output['des1']);?>
                        </p>
                    </div>
                    <div class="col-lg-5 right-info">
                        <div class="project-info">
                            <h3><?php echo esc_html($casesingle_output['info_title']);?></h3>
                            <ul>
                                <?php 
                            if(!empty($casesingle_output['list'])):
                            foreach ($casesingle_output['list'] as $casesingle_list):?>
                                <li>
                                    <?php echo esc_html($casesingle_list['icon_title']);?> <span><?php echo esc_html($casesingle_list['icon_des']);?></span>
                                </li>
                                <?php endforeach; endif;?>
                            </ul>
                            <div class="share">
                                <h4><?php echo esc_html($casesingle_output['social_title']);?></h4>
                                <ul>
                                    <?php 
                            if(!empty($casesingle_output['list1'])):
                            foreach ($casesingle_output['list1'] as $casesingle_social):?>
                                    <li class="<?php echo esc_attr($casesingle_social['social_class']);?>">
                                        <a href="<?php echo esc_url($casesingle_social['social_url']);?>">
                                            <i class="<?php echo esc_attr($casesingle_social['social_icon']);?>"></i>
                                        </a>
                                    </li>
                                   <?php endforeach; endif;?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="main-content">
                
                <p>
                    <?php echo $casesingle_output['details_case'];?>

                </p>
                <div class="row">
                    <div class="col-lg-6 col-md-6">
                        <img src="<?php echo esc_url(wp_get_attachment_image_url( $casesingle_output['img2']['id'], 'full' ));?>" alt="Thumb">
                    </div>
                    <div class="col-lg-6 col-md-6">
                        <img src="<?php echo esc_url(wp_get_attachment_image_url( $casesingle_output['img3']['id'], 'full' ));?>" alt="Thumb">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Project Details Area -->

    <?php }

}