<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Elementor earna hero7 Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class Elementor_earna_hero7_Widget extends \Elementor\Widget_Base {

    /**
     * Get widget name.
     *
     * Retrieve oEmbed widget name.
     *
     * @since 1.0.0
     * @access public
     * @return string Widget name.
     */
    public function get_name() {
        return 'hero7';
    }

    /**
     * Get widget title.
     *
     * Retrieve oEmbed widget title.
     *
     * @since 1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Hero Seven Section', 'earna-core' );
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the oEmbed widget belongs to.
     *
     * @since 1.0.0
     * @access public
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'earna' ];
    }

    /**
     * Register oEmbed widget controls.
     *
     * Add input fields to allow the user to customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls() {

        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__( 'Hero Seven Section', 'earna-core' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();
        
        $repeater->add_control(
            'heroimg',
            [
                'label'     => esc_html__( 'Hero Image', 'earna-core' ),
                'type'      => \Elementor\Controls_Manager::MEDIA,
                'default'   => [
                    'url'       => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $repeater->add_control(
            'title', [
                'label'         => esc_html__( 'Title', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $repeater->add_control(
            'des', [
                'label'         => esc_html__( 'Description', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXTAREA,
                'label_block'   => true,
            ]
        );

        $repeater->add_control(
            'bttext1', [
                'label'         => esc_html__( 'Button Text', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $repeater->add_control(
            'btlink1',
            [
                'label'         => esc_html__( ' Button Link', 'earna-core' ),
                'type'          => \Elementor\Controls_Manager::URL,
                'placeholder'   => esc_html__( 'https://your-link.com', 'earna-core' ),
                'show_external' => true,
                'default'       => [
                    'url'           => '#',
                    'is_external'   => true,
                    'nofollow'      => true,
                ],
            ]
        );

        $this->add_control(
            'list1',
            [
                'label'     => esc_html__( 'hero7 Sliders', 'earna-core' ),
                'type'      => \Elementor\Controls_Manager::REPEATER,
                'fields'    => $repeater->get_controls(),
                'default'   => [
                    [
                        'list_title' => esc_html__( 'Add Sliders', 'earna-core' ),
                    ],
                ],
                'title_field' => '{{{ title }}}',
            ]
        );

        $this->end_controls_section();

    }

    /**
     * Render oEmbed widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render() {

        $hero7_output = $this->get_settings_for_display(); ?>

    <!-- Start Banner 
    ============================================= -->
    <div class="banner-area auto-height text-light banner-style-seven bg-cover">

        
        <div id="bootcarousel" class="carousel slide animate_text" data-ride="carousel">

            <!-- Indicators for slides -->
            <div class="carousel-indicator">
                <ol class="carousel-indicators left center">
                                <?php 
                                $counter = 0;
                                if(!empty($hero7_output['list1'])):
                                foreach ($hero7_output['list1'] as $hero7_slider):?>
                                <li data-target="#bootcarousel" data-slide-to="<?php echo esc_attr($counter);?>" class="<?php if($counter == 0){echo esc_attr("active");}?>"></li>
                                <?php $counter++; endforeach; endif;?>
                            </ol>
        </div>

        <!-- Wrapper for slides -->
        <div class="carousel-inner">
            <?php 
                $counter1 = 0;
                if(!empty($hero7_output['list1'])):
                foreach ($hero7_output['list1'] as $hero7_slider):?>
            <div class="carousel-item bg-cover <?php if($counter1 == 0){echo esc_attr("active");}?>" style="background-image: url(<?php echo esc_url($hero7_slider['heroimg']['url']);?>);">
                <div class="box-table">
                    <div class="box-cell">
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-7 offset-lg-5">
                                    <div class="content" data-animation="animated slideInRight">
                                        <h2><?php echo esc_html($hero7_slider['title']); ?> </h2>
                                        <p>
                                            <?php echo esc_html($hero7_slider['des']); ?>
                                        </p>
                                        <?php if(!empty($hero7_slider['btlink1']['url'] )): ?>
                                        <a class="btn btn-light circle effect btn-md" href="<?php echo esc_url($hero7_slider['btlink1']['url']);?>"><?php echo esc_html($hero7_slider['bttext1']); ?></a>
                                        <?php endif;?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php $counter1++; endforeach; endif;?>
        </div>
        <!-- End Wrapper for slides -->


    </div>
</div>
<!-- End Banner -->

    <?php }

}