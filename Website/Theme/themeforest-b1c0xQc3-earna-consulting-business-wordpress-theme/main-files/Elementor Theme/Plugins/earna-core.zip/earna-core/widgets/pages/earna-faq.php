<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Elementor earna Hero Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class Elementor_earna_faq_Widget extends \Elementor\Widget_Base {

    /**
     * Get widget name.
     *
     * Retrieve oEmbed widget name.
     *
     * @since 1.0.0
     * @access public
     * @return string Widget name.
     */
    public function get_name() {
        return 'faq';
    }

    /**
     * Get widget title.
     *
     * Retrieve oEmbed widget title.
     *
     * @since 1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Faq - Pages Section', 'earna-core' );
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the oEmbed widget belongs to.
     *
     * @since 1.0.0
     * @access public
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'earna' ];
    }

    /**
     * Register oEmbed widget controls.
     *
     * Add input fields to allow the user to customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls() {

        $this->start_controls_section(
            'section2',
            [
                'label' => esc_html__( 'Faq Section', 'earna-core' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'class',
            [
                'label'         => esc_html__( 'Class','earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $repeater1 = new \Elementor\Repeater();

        $repeater1->add_control(
            'heading_id',
            [
                'label'         => esc_html__( 'Heading ID','earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $repeater1->add_control(
            'cl_id',
            [
                'label'         => esc_html__( 'ID','earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $repeater1->add_control(
            'faq_title',
            [
                'label'         => esc_html__( 'Title','earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $repeater1->add_control(
            'faq_des',
            [
                'label'         => esc_html__( 'Description','earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXTAREA,
                'label_block'   => true,
            ]
        );

        $repeater1->add_control(
            'faq_info_title',
            [
                'label'         => esc_html__( 'Info Title','earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $repeater1->add_control(
            'faq_info_text',
            [
                'label'         => esc_html__( 'Info Text','earna-core' ),
                'type'          => \Elementor\Controls_Manager::TEXT,
                'label_block'   => true,
            ]
        );

        $repeater1->add_control(
            'faq_info_url',
            [
                'label'         => esc_html__( 'Info Link', 'tanda-core' ),
                'type'          => \Elementor\Controls_Manager::URL,
                'placeholder'   => esc_html__( 'https://your-link.com', 'tanda-core' ),
                'show_external' => true,
                'default'       => [
                    'url'           => '#',
                    'is_external'   => true,
                    'nofollow'      => true,
                ],
            ]
        );

        $this->add_control(
            'list_two',
            [
                'label'     => esc_html__( 'FAQ Box', 'earna-core' ),
                'type'      => \Elementor\Controls_Manager::REPEATER,
                'fields'    => $repeater1->get_controls(),
                'default'   => [
                    [
                        'list_title' => esc_html__( 'Add Faq Box', 'earna-core' ),
                    ],
                ],
                'title_field' => '{{{ faq_title }}}',
            ]
        );

        $this->end_controls_section();


    }

    /**
     * Render oEmbed widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render() {

        $faq_output = $this->get_settings_for_display(); 
        $faq_box = $faq_output['list_two'];
       ?>

        <!-- Star Faq
============================================= -->
<div class="<?php echo esc_html($faq_output['class']); ?>">
    <div class="container">
        <div class="faq-items">
            <div class="row align-center">

                <div class="col-lg-10 offset-lg-1">
                    <div class="faq-content wow fadeInUp">
                        <div class="accordion" id="accordionExample">
                            <?php 
                  $counter = 0;
                  if(!empty($faq_box)):
                  foreach ($faq_box as $faq_box1) :
                ?>
                            <div class="card">
                                <div class="card-header" id="<?php echo esc_attr($faq_box1['heading_id']);?>">
                                    <h4 class="mb-0" data-toggle="collapse" data-target="#<?php echo esc_attr($faq_box1['cl_id']);?>" aria-expanded="true" aria-controls="<?php echo esc_attr($faq_box1['cl_id']);?>">
                                           <?php echo esc_html($faq_box1['faq_title']);?>
                                    </h4>
                                </div>

                                <div id="<?php echo esc_attr($faq_box1['cl_id']);?>" class="collapse <?php if($counter == 0){echo esc_attr("show");}?>" aria-labelledby="<?php echo esc_attr($faq_box1['heading_id']);?>" data-parent="#accordionExample">
                                    <div class="card-body">
                                        <p>
                                            <?php echo esc_html($faq_box1['faq_des']);?>
                                        </p>
                                        <div class="ask-question">
                                            <span><?php echo esc_html($faq_box1['faq_info_title']);?></span> <a href="<?php echo esc_url($faq_box1['faq_info_url']['url']);?>"><?php echo esc_html($faq_box1['faq_info_text']);?></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                             <?php 
            $counter++;
            endforeach; endif;
                ?>
                            
                            
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</div>
<!-- End Faq -->

    <?php 
}

}